﻿
//# sourceMappingURL=jquery.chatjs.interfaces.js.map
