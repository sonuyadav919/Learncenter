interface JQuery {
    autosize: (options: any) => void;
}