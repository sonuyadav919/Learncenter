facebook-like-chat
==================

A small script to demonstrate facebook like chat application using html jquery and css

Demo : http://packetcode.com/apps/facebook-like-chat/

The application development has been captured to videos..check out the playlist to learn the code bit by bit
Videos : http://www.youtube.com/playlist?list=PLNeMoaZ9VHP9zQd08bOnxZYdAyTS5e-r6
